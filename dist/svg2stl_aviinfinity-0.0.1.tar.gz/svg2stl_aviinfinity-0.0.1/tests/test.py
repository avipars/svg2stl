from svg2stl import convert_svg_to_stl
convert_svg_to_stl("example.svg", thickness=2.0)